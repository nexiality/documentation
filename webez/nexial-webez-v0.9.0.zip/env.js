APP_ENV = "distro";
APP_DOC_URL = "https://nexiality.github.io/documentation/commands/web";
HELP_URL = "https://nexiality.github.io/documentation/webez";